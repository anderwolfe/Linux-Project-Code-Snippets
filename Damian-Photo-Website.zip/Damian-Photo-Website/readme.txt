JSON notes:

--

You can do this if you want a thumbnail. If you don't do it, the thumbnail will just be the image. You can do this for youtube videos too:
"thumb": "images/imagename.jpg",

--

Can do these for different sized images on the main page. If left blank it will just default to medium:
"size": "s"
"size": "m"
"size": "l"
"size": "xl"