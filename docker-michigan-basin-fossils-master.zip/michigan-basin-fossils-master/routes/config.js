
module.exports = {
  imagePath: "/usr/src/app/images/",
  project_id: 1,
  port: 8080,
  credentials: {
    host: "127.0.0.1",
    user: "database_user",
    password: "database_password",
    database: "database_name"
  }
};
